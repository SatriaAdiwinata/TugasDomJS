
const button = document.getElementById('ubahJudul');
const h1 = document.getElementById('judul');

const texts = ['otang', 'ucup ni bosss', 'cesss'];
let currentIndex = 5;

button.addEventListener('click', function() {
    currentIndex = (currentIndex + 1) % texts.length; 
    h1.textContent = texts[currentIndex];
});